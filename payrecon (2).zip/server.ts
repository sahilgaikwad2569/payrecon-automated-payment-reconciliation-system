import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'PayRecon',
  password: process.env.DB_PASSWORD || 'payal19052005',
  port: parseInt(process.env.DB_PORT || '5432'),
});

async function initDb() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS transactions (
        transaction_id VARCHAR(50) PRIMARY KEY,
        date DATE NOT NULL,
        amount DECIMAL(15, 3) NOT NULL
      );
      CREATE TABLE IF NOT EXISTS settlements (
        id SERIAL PRIMARY KEY,
        transaction_id VARCHAR(50) NOT NULL,
        settlement_date DATE NOT NULL,
        amount DECIMAL(15, 3) NOT NULL
      );
    `);
    console.log('Database tables initialized');
  } catch (err) {
    console.error('Error initializing database:', err);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  await initDb();

  // API Routes
  app.get('/api/data', async (req, res) => {
    try {
      const txns = await pool.query('SELECT * FROM transactions');
      const sets = await pool.query('SELECT * FROM settlements');
      res.json({
        transactions: txns.rows,
        settlements: sets.rows
      });
    } catch (err) {
      res.status(500).json({ error: 'Failed to fetch data' });
    }
  });

  app.post('/api/sync', async (req, res) => {
    const { transactions, settlements } = req.body;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      
      // Clear existing data for demo purposes (or handle updates)
      await client.query('DELETE FROM settlements');
      await client.query('DELETE FROM transactions');

      for (const t of transactions) {
        await client.query(
          'INSERT INTO transactions (transaction_id, date, amount) VALUES ($1, $2, $3)',
          [t.transaction_id, t.date, t.amount]
        );
      }

      for (const s of settlements) {
        await client.query(
          'INSERT INTO settlements (transaction_id, settlement_date, amount) VALUES ($1, $2, $3)',
          [s.transaction_id, s.settlement_date, s.amount]
        );
      }

      await client.query('COMMIT');
      res.json({ message: 'Data synced successfully' });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(err);
      res.status(500).json({ error: 'Failed to sync data' });
    } finally {
      client.release();
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
