export interface Transaction {
  transaction_id: string;
  date: string;
  amount: number;
}

export interface Settlement {
  transaction_id: string;
  settlement_date: string;
  amount: number;
}

export interface ReconIssue {
  type: 'MISSING_SETTLEMENT' | 'EXTRA_SETTLEMENT' | 'DUPLICATE_SETTLEMENT' | 'LATE_SETTLEMENT' | 'AMOUNT_MISMATCH';
  transaction_id: string;
  details: string;
  severity: 'high' | 'medium' | 'low';
}

export interface ReconReport {
  missingSettlements: Transaction[];
  extraSettlements: Settlement[];
  duplicateSettlements: Settlement[];
  lateSettlements: { transaction: Transaction; settlement: Settlement }[];
  amountMismatches: { transaction: Transaction; settlement: Settlement; difference: number }[];
}
