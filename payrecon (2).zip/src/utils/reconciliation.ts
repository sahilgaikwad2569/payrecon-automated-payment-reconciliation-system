import { Transaction, Settlement, ReconReport } from '../types';

export function reconcile(transactions: Transaction[], settlements: Settlement[]): ReconReport {
  const report: ReconReport = {
    missingSettlements: [],
    extraSettlements: [],
    duplicateSettlements: [],
    lateSettlements: [],
    amountMismatches: [],
  };

  const settlementMap = new Map<string, Settlement[]>();
  settlements.forEach(s => {
    const existing = settlementMap.get(s.transaction_id) || [];
    settlementMap.set(s.transaction_id, [...existing, s]);
  });

  const transactionMap = new Map<string, Transaction>();
  transactions.forEach(t => transactionMap.set(t.transaction_id, t));

  // Check Transactions for missing or mismatched settlements
  transactions.forEach(t => {
    const matchedSettlements = settlementMap.get(t.transaction_id);

    if (!matchedSettlements || matchedSettlements.length === 0) {
      report.missingSettlements.push(t);
    } else {
      // Check for duplicates
      if (matchedSettlements.length > 1) {
        // All but the first one are considered duplicates for this report's purpose
        report.duplicateSettlements.push(...matchedSettlements.slice(1));
      }

      const s = matchedSettlements[0];

      // Check for amount mismatch (using a small epsilon for float rounding)
      const diff = Math.abs(t.amount - s.amount);
      if (diff > 0.001) {
        report.amountMismatches.push({ transaction: t, settlement: s, difference: t.amount - s.amount });
      }

      // Check for late settlement (cross-month)
      const tDate = new Date(t.date);
      const sDate = new Date(s.settlement_date);
      if (tDate.getMonth() !== sDate.getMonth() || tDate.getFullYear() !== sDate.getFullYear()) {
        report.lateSettlements.push({ transaction: t, settlement: s });
      }
    }
  });

  // Check Settlements for extra records (no matching transaction)
  settlements.forEach(s => {
    if (!transactionMap.has(s.transaction_id)) {
      report.extraSettlements.push(s);
    }
  });

  return report;
}

export const SAMPLE_TRANSACTIONS_CSV = `transaction_id,date,amount
TXN001,2023-10-30,100.00
TXN002,2023-10-15,50.005
TXN003,2023-10-10,75.00
TXN005,2023-10-20,200.00`;

export const SAMPLE_SETTLEMENTS_CSV = `transaction_id,settlement_date,amount
TXN001,2023-11-01,100.00
TXN002,2023-10-16,50.00
TXN003,2023-10-11,75.00
TXN003,2023-10-12,75.00
TXN004,2023-10-12,-20.00`;

export const PYTHON_CODE_TEMPLATE = `
import pandas as pd
import io
import psycopg2 # pip install psycopg2-binary

# Database Configuration (for PostgreSQL storage)
DB_CONFIG = {
    "user": "postgres",
    "host": "localhost",
    "database": "PayRecon",
    "password": "payal19052005",
    "port": 5432
}

# 1. Generate sample datasets
transactions_csv = """transaction_id,date,amount
TXN001,2023-10-30,100.00
TXN002,2023-10-15,50.005
TXN003,2023-10-10,75.00
TXN005,2023-10-20,200.00"""

settlements_csv = """transaction_id,settlement_date,amount
TXN001,2023-11-01,100.00
TXN002,2023-10-16,50.00
TXN003,2023-10-11,75.00
TXN003,2023-10-12,75.00
TXN004,2023-10-12,-20.00"""

def save_to_postgres(df_txn, df_set):
    """Optional: Save results to PostgreSQL"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        
        # Create tables
        cur.execute("CREATE TABLE IF NOT EXISTS transactions (transaction_id VARCHAR(50) PRIMARY KEY, date DATE, amount DECIMAL(15,3))")
        cur.execute("CREATE TABLE IF NOT EXISTS settlements (id SERIAL PRIMARY KEY, transaction_id VARCHAR(50), settlement_date DATE, amount DECIMAL(15,3))")
        
        # Insert Transactions
        for _, row in df_txn.iterrows():
            cur.execute("INSERT INTO transactions (transaction_id, date, amount) VALUES (%s, %s, %s) ON CONFLICT DO NOTHING", 
                        (row['transaction_id'], row['date'], row['amount']))
            
        # Insert Settlements
        for _, row in df_set.iterrows():
            cur.execute("INSERT INTO settlements (transaction_id, settlement_date, amount) VALUES (%s, %s, %s)", 
                        (row['transaction_id'], row['settlement_date'], row['amount']))
            
        conn.commit()
        print("\\n[DB] Data successfully saved to PostgreSQL.")
        cur.close()
        conn.close()
    except Exception as e:
        print(f"\\n[DB Error] Could not save to database: {e}")

def reconcile_payments():
    # Load datasets
    df_txn = pd.read_csv(io.StringIO(transactions_csv))
    df_set = pd.read_csv(io.StringIO(settlements_csv))
    
    # Convert dates to datetime
    df_txn['date'] = pd.to_datetime(df_txn['date'])
    df_set['settlement_date'] = pd.to_datetime(df_set['settlement_date'])
    
    print("=== RECONCILIATION REPORT ===\\n")
    
    # a. Missing Settlements
    missing = df_txn[~df_txn['transaction_id'].isin(df_set['transaction_id'])]
    print("--- Missing Settlements ---")
    print(missing if not missing.empty else "None")
    
    # b. Extra Settlements (Refunds or unmatched)
    extra = df_set[~df_set['transaction_id'].isin(df_txn['transaction_id'])]
    print("\\n--- Extra Settlements (Unmatched) ---")
    print(extra if not extra.empty else "None")
    
    # c. Duplicate Records in Settlements
    duplicates = df_set[df_set.duplicated(subset=['transaction_id'], keep='first')]
    print("\\n--- Duplicate Settlements ---")
    print(duplicates if not duplicates.empty else "None")
    
    # Merge for comparison
    merged = pd.merge(df_txn, df_set, on='transaction_id', how='inner')
    
    # d. Late Settlements (Cross-month)
    merged['txn_month'] = merged['date'].dt.to_period('M')
    merged['set_month'] = merged['settlement_date'].dt.to_period('M')
    late = merged[merged['txn_month'] != merged['set_month']]
    print("\\n--- Late Settlements (Cross-month) ---")
    print(late[['transaction_id', 'date', 'settlement_date']] if not late.empty else "None")
    
    # e. Amount Mismatches (Rounding or errors)
    mismatches = merged[abs(merged['amount_x'] - merged['amount_y']) > 0.001]
    print("\\n--- Amount Mismatches ---")
    if not mismatches.empty:
        mismatches = mismatches.copy()
        mismatches['diff'] = mismatches['amount_x'] - mismatches['amount_y']
        print(mismatches[['transaction_id', 'amount_x', 'amount_y', 'diff']])
    else:
        print("None")
        
    # Save to DB
    save_to_postgres(df_txn, df_set)

if __name__ == "__main__":
    reconcile_payments()
`;
