/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';
import { 
  FileText, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Copy, 
  AlertTriangle, 
  Download, 
  Code,
  Database,
  ArrowRightLeft
} from 'lucide-react';
import { Transaction, Settlement, ReconReport } from './types';
import { reconcile, SAMPLE_TRANSACTIONS_CSV, SAMPLE_SETTLEMENTS_CSV, PYTHON_CODE_TEMPLATE } from './utils/reconciliation';
import { cn } from './lib/utils';

export default function App() {
  const [txnCsv, setTxnCsv] = useState(SAMPLE_TRANSACTIONS_CSV);
  const [setCsv, setSetCsv] = useState(SAMPLE_SETTLEMENTS_CSV);
  const [report, setReport] = useState<ReconReport | null>(null);
  const [view, setView] = useState<'dashboard' | 'data' | 'python'>('dashboard');
  const [syncing, setSyncing] = useState(false);

  const handleReconcile = () => {
    const txns = Papa.parse<Transaction>(txnCsv, { header: true, dynamicTyping: true }).data.filter(t => t.transaction_id);
    const sets = Papa.parse<Settlement>(setCsv, { header: true, dynamicTyping: true }).data.filter(s => s.transaction_id);
    const result = reconcile(txns, sets);
    setReport(result);
  };

  const handleSyncToDb = async () => {
    setSyncing(true);
    try {
      const txns = Papa.parse<Transaction>(txnCsv, { header: true, dynamicTyping: true }).data.filter(t => t.transaction_id);
      const sets = Papa.parse<Settlement>(setCsv, { header: true, dynamicTyping: true }).data.filter(s => s.transaction_id);
      
      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transactions: txns, settlements: sets })
      });
      
      if (response.ok) {
        alert('Data successfully stored in PostgreSQL database!');
      } else {
        alert('Failed to sync data to database.');
      }
    } catch (err) {
      console.error(err);
      alert('Error connecting to backend server.');
    } finally {
      setSyncing(false);
    }
  };

  const fetchFromDb = async () => {
    try {
      const response = await fetch('/api/data');
      if (response.ok) {
        const { transactions, settlements } = await response.json();
        if (transactions.length > 0 || settlements.length > 0) {
          setTxnCsv(Papa.unparse(transactions));
          setSetCsv(Papa.unparse(settlements));
          alert('Data loaded from PostgreSQL!');
        } else {
          alert('Database is currently empty.');
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    handleReconcile();
  }, []);

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Header */}
      <header className="border-b border-[#141414] p-6 flex justify-between items-center bg-[#E4E3E0] sticky top-0 z-10">
        <div>
          <h1 className="text-2xl font-serif italic tracking-tight flex items-center gap-3">
            <ArrowRightLeft className="w-6 h-6" />
            PayRecon <span className="text-xs not-italic font-mono opacity-50 ml-2 uppercase tracking-widest">v1.0.0</span>
          </h1>
          <p className="text-xs font-mono opacity-60 mt-1">Automated Payments Reconciliation Engine</p>
        </div>
        <nav className="flex gap-4">
          <button 
            onClick={() => setView('dashboard')}
            className={cn(
              "px-4 py-2 text-xs font-mono uppercase tracking-widest transition-all border border-transparent",
              view === 'dashboard' ? "bg-[#141414] text-[#E4E3E0]" : "hover:border-[#141414]"
            )}
          >
            Dashboard
          </button>
          <button 
            onClick={() => setView('data')}
            className={cn(
              "px-4 py-2 text-xs font-mono uppercase tracking-widest transition-all border border-transparent",
              view === 'data' ? "bg-[#141414] text-[#E4E3E0]" : "hover:border-[#141414]"
            )}
          >
            Raw Data
          </button>
          <button 
            onClick={() => setView('python')}
            className={cn(
              "px-4 py-2 text-xs font-mono uppercase tracking-widest transition-all border border-transparent",
              view === 'python' ? "bg-[#141414] text-[#E4E3E0]" : "hover:border-[#141414]"
            )}
          >
            Python Script
          </button>
          <div className="h-8 w-[1px] bg-[#141414]/20 mx-2" />
          <button 
            onClick={handleSyncToDb}
            disabled={syncing}
            className="px-4 py-2 text-xs font-mono uppercase tracking-widest bg-green-600 text-white hover:bg-green-700 disabled:opacity-50 transition-all"
          >
            {syncing ? 'Syncing...' : 'Save to PG'}
          </button>
          <button 
            onClick={fetchFromDb}
            className="px-4 py-2 text-xs font-mono uppercase tracking-widest border border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0] transition-all"
          >
            Load from PG
          </button>
        </nav>
      </header>

      <main className="p-6 max-w-7xl mx-auto">
        {view === 'dashboard' && report && (
          <div className="space-y-8 animate-in fade-in duration-500">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <StatCard 
                label="Missing" 
                value={report.missingSettlements.length} 
                icon={<AlertCircle className="w-4 h-4 text-red-600" />}
                status={report.missingSettlements.length > 0 ? 'error' : 'success'}
              />
              <StatCard 
                label="Extra" 
                value={report.extraSettlements.length} 
                icon={<Database className="w-4 h-4 text-amber-600" />}
                status={report.extraSettlements.length > 0 ? 'warning' : 'success'}
              />
              <StatCard 
                label="Duplicates" 
                value={report.duplicateSettlements.length} 
                icon={<Copy className="w-4 h-4 text-amber-600" />}
                status={report.duplicateSettlements.length > 0 ? 'warning' : 'success'}
              />
              <StatCard 
                label="Late" 
                value={report.lateSettlements.length} 
                icon={<Clock className="w-4 h-4 text-blue-600" />}
                status={report.lateSettlements.length > 0 ? 'warning' : 'success'}
              />
              <StatCard 
                label="Mismatches" 
                value={report.amountMismatches.length} 
                icon={<AlertTriangle className="w-4 h-4 text-red-600" />}
                status={report.amountMismatches.length > 0 ? 'error' : 'success'}
              />
            </div>

            {/* Detailed Sections */}
            <div className="space-y-12">
              <ReconSection 
                title="Missing Settlements" 
                description="Transactions recorded in our platform but not found in bank settlements."
                data={report.missingSettlements}
                renderRow={(t) => (
                  <div key={t.transaction_id} className="data-row">
                    <span className="font-mono text-[10px] opacity-40">ID</span>
                    <span className="data-value">{t.transaction_id}</span>
                    <span className="data-value">{t.date}</span>
                    <span className="data-value text-right">${t.amount.toFixed(2)}</span>
                  </div>
                )}
              />

              <ReconSection 
                title="Extra Settlements" 
                description="Settlement records from the bank that have no matching transaction in our system."
                data={report.extraSettlements}
                renderRow={(s) => (
                  <div key={`${s.transaction_id}-${s.settlement_date}`} className="data-row">
                    <span className="font-mono text-[10px] opacity-40">ID</span>
                    <span className="data-value">{s.transaction_id}</span>
                    <span className="data-value">{s.settlement_date}</span>
                    <span className="data-value text-right">${s.amount.toFixed(2)}</span>
                  </div>
                )}
              />

              <ReconSection 
                title="Late Settlements (Cross-Month)" 
                description="Transactions that settled in a different month than they were recorded."
                data={report.lateSettlements}
                renderRow={({ transaction, settlement }) => (
                  <div key={transaction.transaction_id} className="data-row grid-cols-[40px_1.5fr_1fr_1fr_1fr]">
                    <span className="font-mono text-[10px] opacity-40">ID</span>
                    <span className="data-value">{transaction.transaction_id}</span>
                    <span className="data-value">{transaction.date}</span>
                    <span className="data-value">{settlement.settlement_date}</span>
                    <span className="data-value text-right">${transaction.amount.toFixed(2)}</span>
                  </div>
                )}
                headers={['ID', 'TXN DATE', 'SETTLE DATE', 'AMOUNT']}
              />

              <ReconSection 
                title="Amount Mismatches" 
                description="Discrepancies between transaction amount and settlement amount (e.g. rounding errors)."
                data={report.amountMismatches}
                renderRow={({ transaction, settlement, difference }) => (
                  <div key={transaction.transaction_id} className="data-row grid-cols-[40px_1.5fr_1fr_1fr_1fr]">
                    <span className="font-mono text-[10px] opacity-40">ID</span>
                    <span className="data-value">{transaction.transaction_id}</span>
                    <span className="data-value">${transaction.amount.toFixed(3)}</span>
                    <span className="data-value">${settlement.amount.toFixed(3)}</span>
                    <span className={cn("data-value text-right font-bold", difference > 0 ? "text-red-600" : "text-green-600")}>
                      {difference > 0 ? '+' : ''}{difference.toFixed(3)}
                    </span>
                  </div>
                )}
                headers={['ID', 'PLATFORM', 'BANK', 'DIFF']}
              />
            </div>

            {/* Footer Notes */}
            <div className="border-t border-[#141414] pt-8 grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h3 className="font-serif italic text-sm mb-4">Assumptions Made</h3>
                <ul className="text-xs font-mono space-y-2 opacity-70">
                  <li>• Transaction IDs are unique identifiers across both systems.</li>
                  <li>• Settlement date is always equal to or later than transaction date.</li>
                  <li>• A tolerance of 0.001 is used for amount comparisons to handle floating point precision.</li>
                  <li>• "Late Settlement" is defined as a change in calendar month.</li>
                </ul>
              </div>
              <div>
                <h3 className="font-serif italic text-sm mb-4">System Limitations</h3>
                <ul className="text-xs font-mono space-y-2 opacity-70">
                  <li>• 1. Batching: Does not handle multiple transactions bundled into a single settlement.</li>
                  <li>• 2. Currency: Assumes all transactions are in the same base currency.</li>
                  <li>• 3. Scaling: In-memory processing is limited to ~100k records; production requires distributed compute (Spark/SQL).</li>
                </ul>
              </div>
              <div className="md:col-span-2">
                <h3 className="font-serif italic text-sm mb-4">Test Cases & Expected Results</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-[10px] font-mono opacity-70">
                  <div className="border border-[#141414]/20 p-3">
                    <p className="font-bold mb-1 underline">TXN001: Late Settlement</p>
                    <p>Oct 30 &rarr; Nov 01. Expected: Flagged as LATE_SETTLEMENT due to month change.</p>
                  </div>
                  <div className="border border-[#141414]/20 p-3">
                    <p className="font-bold mb-1 underline">TXN002: Rounding Error</p>
                    <p>50.005 vs 50.00. Expected: Flagged as AMOUNT_MISMATCH (Diff: 0.005).</p>
                  </div>
                  <div className="border border-[#141414]/20 p-3">
                    <p className="font-bold mb-1 underline">TXN003: Duplicates</p>
                    <p>Two settlement records. Expected: Second record flagged as DUPLICATE.</p>
                  </div>
                  <div className="border border-[#141414]/20 p-3">
                    <p className="font-bold mb-1 underline">TXN004: Extra/Refund</p>
                    <p>Settlement only. Expected: Flagged as EXTRA_SETTLEMENT (Unmatched).</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'data' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-serif italic text-lg">transactions.csv</h3>
                <button onClick={() => setTxnCsv(SAMPLE_TRANSACTIONS_CSV)} className="text-[10px] font-mono uppercase tracking-widest opacity-50 hover:opacity-100 underline">Reset to Sample</button>
              </div>
              <textarea 
                value={txnCsv}
                onChange={(e) => setTxnCsv(e.target.value)}
                className="w-full h-[400px] bg-white border border-[#141414] p-4 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-[#141414]"
              />
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-serif italic text-lg">settlements.csv</h3>
                <button onClick={() => setSetCsv(SAMPLE_SETTLEMENTS_CSV)} className="text-[10px] font-mono uppercase tracking-widest opacity-50 hover:opacity-100 underline">Reset to Sample</button>
              </div>
              <textarea 
                value={setCsv}
                onChange={(e) => setSetCsv(e.target.value)}
                className="w-full h-[400px] bg-white border border-[#141414] p-4 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-[#141414]"
              />
            </div>
            <div className="lg:col-span-2 flex justify-center pt-4">
              <button 
                onClick={() => {
                  handleReconcile();
                  setView('dashboard');
                }}
                className="bg-[#141414] text-[#E4E3E0] px-12 py-4 font-mono uppercase tracking-[0.2em] hover:bg-opacity-90 transition-all"
              >
                Run Reconciliation
              </button>
            </div>
          </div>
        )}

        {view === 'python' && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-serif italic text-xl">Python Reconciliation Script</h3>
                <p className="text-xs font-mono opacity-60 mt-1">Standalone pandas implementation for local execution.</p>
              </div>
              <button 
                onClick={() => {
                  const blob = new Blob([PYTHON_CODE_TEMPLATE], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'reconcile.py';
                  a.click();
                }}
                className="flex items-center gap-2 px-4 py-2 border border-[#141414] text-xs font-mono uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-all"
              >
                <Download className="w-4 h-4" />
                Download .py
              </button>
            </div>
            <div className="bg-[#141414] text-[#E4E3E0] p-6 rounded-sm overflow-x-auto">
              <pre className="font-mono text-xs leading-relaxed">
                {PYTHON_CODE_TEMPLATE}
              </pre>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function StatCard({ label, value, icon, status }: { label: string, value: number, icon: React.ReactNode, status: 'success' | 'warning' | 'error' }) {
  return (
    <div className={cn(
      "border border-[#141414] p-4 flex flex-col justify-between h-24 transition-all",
      status === 'error' && value > 0 ? "bg-red-50" : status === 'warning' && value > 0 ? "bg-amber-50" : "bg-white"
    )}>
      <div className="flex justify-between items-start">
        <span className="text-[10px] font-mono uppercase tracking-widest opacity-50">{label}</span>
        {icon}
      </div>
      <span className="text-3xl font-serif italic">{value}</span>
    </div>
  );
}

function ReconSection({ title, description, data, renderRow, headers }: { 
  title: string, 
  description: string, 
  data: any[], 
  renderRow: (item: any) => React.ReactNode,
  headers?: string[]
}) {
  if (data.length === 0) return null;

  return (
    <section className="space-y-4">
      <div className="border-b border-[#141414] pb-2">
        <h2 className="text-xl font-serif italic">{title}</h2>
        <p className="text-xs font-mono opacity-60">{description}</p>
      </div>
      <div className="border border-[#141414] bg-white">
        <div className={cn("grid p-4 border-b border-[#141414] bg-[#f9f9f9]", headers ? `grid-cols-[40px_1.5fr_1fr_1fr_1fr]` : "grid-cols-[40px_1.5fr_1fr_1fr]")}>
          <span className="col-header">#</span>
          {(headers || ['ID', 'DATE', 'AMOUNT']).map(h => (
            <span key={h} className={cn("col-header", h === 'AMOUNT' || h === 'DIFF' ? "text-right" : "")}>{h}</span>
          ))}
        </div>
        <div className="divide-y divide-[#141414]/10">
          {data.map(renderRow)}
        </div>
      </div>
    </section>
  );
}
